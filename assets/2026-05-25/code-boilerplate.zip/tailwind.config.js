/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'hygge-primary': 'var(--color-primary-brown)',
        'hygge-secondary': 'var(--color-secondary-cream)',
        'hygge-accent': 'var(--color-accent-orange)',
        'hygge-background': 'var(--color-background-light)',
        'hygge-text': 'var(--color-text-dark)',
      },
      fontFamily: {
        display: ['"Playfair Display"', 'serif'],
        body: ['"Inter"', 'sans-serif'],
      },
      boxShadow: {
        'hygge-soft': '0px 8px 20px -5px rgba(62, 39, 35, 0.4), inset 0px 2px 5px rgba(243, 233, 221, 0.7)',
        'hygge-hover': '0px 12px 30px -5px rgba(62, 39, 35, 0.5), inset 0px 2px 6px rgba(243, 233, 221, 0.8)'
      },
    },
  },
  plugins: [],
}
