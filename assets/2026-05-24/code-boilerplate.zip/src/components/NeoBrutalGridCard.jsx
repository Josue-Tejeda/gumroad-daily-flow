import React, { useState, useEffect } from 'react';
import '../styles/neoBrutalGridTheme.css';

const NeoBrutalGridCard = () => {
  const [cpuUsage, setCpuUsage] = useState(0);
  const [memoryUsage, setMemoryUsage] = useState(0);
  const [diskUsage, setDiskUsage] = useState(0);
  const [networkActivity, setNetworkActivity] = useState({ up: 0, down: 0 });
  const [status, setStatus] = useState('Online');
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate real-time data
      setCpuUsage(Math.floor(Math.random() * 40) + 20); // 20-60%
      setMemoryUsage(Math.floor(Math.random() * 30) + 40); // 40-70%
      setDiskUsage(Math.floor(Math.random() * 20) + 70); // 70-90%
      setNetworkActivity({
        up: (Math.random() * 5).toFixed(2), // MB/s
        down: (Math.random() * 20).toFixed(2), // MB/s
      });

      const statuses = ['Online', 'Online', 'Online', 'Degraded', 'Offline', 'Rebooting']; // More 'Online' to make it realistic
      if (Math.random() < 0.05) { // 5% chance to change status
        setStatus(statuses[Math.floor(Math.random() * statuses.length)]);
      }
      setLastUpdate(new Date());
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval);
  }, []);

  const getStatusClass = (currentStatus) => {
    switch (currentStatus) {
      case 'Online':
        return 'neon-text';
      case 'Degraded':
        return 'status-degraded';
      case 'Offline':
        return 'status-offline';
      case 'Rebooting':
        return 'status-rebooting';
      default:
        return '';
    }
  };

  const getStatusIndicator = (currentStatus) => {
    switch (currentStatus) {
      case 'Online':
        return '🟢';
      case 'Degraded':
        return '🟠';
      case 'Offline':
        return '🔴';
      case 'Rebooting':
        return '🔄';
      default:
        return '⚪';
    }
  };

  return (
    <div
      className="brutal-element"
      style={{
        width: '450px',
        padding: '25px',
        display: 'flex',
        flexDirection: 'column',
        gap: '20px',
        fontFamily: "'Roboto Mono', monospace",
        boxSizing: 'border-box'
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: '10px', borderBottom: `1px solid var(--color-secondary)` }}>
        <h2 style={{ margin: 0, fontSize: '1.4em', fontWeight: 'bold', color: 'var(--color-text)' }}>
          SYSTEM OVERVIEW
        </h2>
        <span className={getStatusClass(status)} style={{ fontSize: '1em' }}>
          {getStatusIndicator(status)} {status}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* CPU Usage */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: 'var(--color-secondary)' }}>CPU</span>
            <span className="neon-text">{cpuUsage}%</span>
          </div>
          <div className="progress-bar-container">
            <div className="progress-bar" style={{ width: `${cpuUsage}%` }}></div>
          </div>
        </div>

        {/* Memory Usage */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: 'var(--color-secondary)' }}>RAM</span>
            <span className="neon-text">{memoryUsage}%</span>
          </div>
          <div className="progress-bar-container">
            <div className="progress-bar" style={{ width: `${memoryUsage}%` }}></div>
          </div>
        </div>

        {/* Disk Usage */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: 'var(--color-secondary)' }}>DISK</span>
            <span className="neon-text">{diskUsage}%</span>
          </div>
          <div className="progress-bar-container">
            <div className="progress-bar" style={{ width: `${diskUsage}%` }}></div>
          </div>
        </div>

        {/* Network Activity */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: 'var(--color-secondary)' }}>NET</span>
            <div style={{ display: 'flex', gap: '10px' }}>
              <span className="neon-text">⬇️ {networkActivity.down} MB/s</span>
              <span className="neon-text">⬆️ {networkActivity.up} MB/s</span>
            </div>
          </div>
          <div style={{
            height: '8px',
            position: 'relative',
            background: 'var(--color-secondary)',
            borderRadius: '2px',
            overflow: 'hidden'
          }}>
            {/* Simple network activity visualization - can be enhanced */}
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              background: 'linear-gradient(90deg, var(--color-accent) 0%, transparent 100%)',
              opacity: 0.2,
              animation: 'networkFlow 2s linear infinite'
            }}></div>
          </div>
        </div>
      </div>

      <div style={{ borderTop: `1px solid var(--color-secondary)`, paddingTop: '15px', marginTop: '10px' }}>
        <p style={{ margin: 0, fontSize: '0.85em', color: 'var(--color-secondary)' }}>
          Last update: <span className="neon-text">{lastUpdate.toLocaleTimeString()}</span>
        </p>
      </div>
    </div>
  );
};

export default NeoBrutalGridCard;