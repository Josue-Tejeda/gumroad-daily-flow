# Neon Glitch Metropolis Data Card

## Overview

Immerse your application in the high-tech, near-future urban landscape of the "Neon Glitch Metropolis" with this **dynamic Data Card component**. Designed as a premium developer asset, this React component visualizes key metrics with a stunning blend of gritty realism, vibrant neon accents, and subtle digital glitch effects.

It features sharp geometric lines, layered transparency, brushed metallic textures, and an interactive glitch effect that triggers on data updates, creating a sense of a living, breathing, data-rich environment.

## Theme: Neon Glitch Metropolis

This component embodies the "Neon Glitch Metropolis" theme, a world where digital data streams flow through rain-slicked neon streets, blending gritty realism with vibrant, holographic interfaces. It's built for projects that demand a futuristic, cyberpunk-inspired aesthetic with a focus on high-fidelity visual feedback.

### Aesthetic Styling Details

*   **High-tech, Near-Future Urban Landscape**: The design reflects a bustling metropolis where technology is deeply integrated into every facade.
*   **Sharp, Geometric Lines**: Clean and precise edges define elements, creating a sense of order amidst digital chaos.
*   **Layered Transparency & Glassmorphism**: UI elements often feature translucent backgrounds, allowing for depth and context from underlying elements.
*   **Dynamic Light & Shadow**: Neon glows pierce through darker atmospheric backgrounds, highlighting key information.
*   **Brushed Metallic Textures & Holographic Sheens**: Subtle textural details give elements a premium, tactile feel, complemented by ethereal, shimmering overlays.
*   **Digital Glitch Effects**: Controlled imperfections are introduced through programmatic glitches, adding a dynamic, 'live' feel, reminiscent of data streams flickering through the network.
*   **Typography**: Clean, monospaced fonts (`'SF Mono'`, `'Roboto Mono'`, `'Space Mono'`) with glowing outlines enhance readability in a futuristic context.
*   **Grids & Circuit Board Patterns**: Subtly integrated into backgrounds and overlays, reinforcing the theme of interconnected digital space.
*   **Interactive UI**: Smooth, futuristic transitions and subtle particle effects (simulated with CSS for status dots) create an engaging user experience.

### Color Palette

The component is meticulously styled using a defined color palette to maintain thematic consistency and ease of customization:

*   **Primary**: `#5A189A` (Deep Purple) - Used for deeper accents and background glows.
*   **Secondary**: `#00C2FF` (Cyber Cyan) - Dominant neon accent, highlighting primary data and interactive elements.
*   **Accent**: `#FF00FF` (Electric Magenta) - Provides striking contrast and indicates critical states or warnings.
*   **Background**: `#100F0F` (Dark Metropolis Black) - The foundational dark tone, allowing neon elements to pop.
*   **Text**: `#E0E0E0` (Digital Grey) - Ensures readability for all textual information.

These colors are defined as CSS variables for easy theming.

## Installation

This asset is a React component and requires a React environment (e.g., created with Create React App, Next.js, or Vite).

1.  **Create the files**: Copy the provided `theme.css`, `NeonGlitchDataCard.module.css`, and `NeonGlitchDataCard.jsx` into your project.
    *   `src/styles/theme.css`
    *   `src/components/NeonGlitchDataCard/NeonGlitchDataCard.module.css`
    *   `src/components/NeonGlitchDataCard/NeonGlitchDataCard.jsx`

2.  **Import Global Styles**: Ensure `theme.css` is imported at the root of your application (e.g., `src/index.js` or `src/App.js`) to apply the global theme variables and base styles.

    ```jsx
    // src/index.js or src/App.js
    import React from 'react';
    import ReactDOM from 'react-dom/client';
    import './styles/theme.css'; // Global theme styles
    import App from './App';

    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
    ```

3.  **Import Component**: Import `NeonGlitchDataCard.jsx` into any React component where you wish to use it.

## Usage

The `NeonGlitchDataCard` component is highly configurable via props, allowing you to display various types of data with consistent styling.

### Props

| Prop          | Type     | Default       | Description                                                               |
| :------------ | :------- | :------------ | :------------------------------------------------------------------------ |
| `title`       | `string` | `