import React from 'react';
import DeepSeaDataDisplay from './components/DeepSeaDataDisplay';
import theme from './theme';
import './index.css';

function App() {
  return (
    <div style={{ backgroundColor: theme.colors.background, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <DeepSeaDataDisplay />
    </div>
  );
}

export default App;