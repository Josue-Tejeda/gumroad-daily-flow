const theme = {
  colors: {
    primary: '#0A1C2C',
    secondary: '#1A4F6D',
    accent: '#00F0FF',
    background: '#07101C',
    text: '#E0EBF5',
    textMuted: '#8BA4B5',
  },
  fonts: {
    body: 'Arial, sans-serif',
    display: 'Montserrat, sans-serif',
  },
  spacing: {
    small: '8px',
    medium: '16px',
    large: '24px',
  },
  borderRadius: '8px',
};

export default theme;