# Abyssal Lumina Calm - Deep Sea Data Monitor

Dive into a tranquil digital experience with the "Abyssal Lumina Calm" Deep Sea Data Monitor component. This React dashboard widget echoes the mysterious depths and serene bioluminescence of the deep ocean, providing a calm yet engaging display for data.

## Theme Description

The "Abyssal Lumina Calm" theme evokes the profound tranquility and subtle, enchanting glow found in the deep ocean. It combines dark, oceanic blues with a vibrant, bioluminescent accent to create a unique and immersive user interface.

**Colors Used:**
*   **Primary:** `#0A1C2C` (Deep Ocean Blue - for main containers and strong elements)
*   **Secondary:** `#1A4F6D` (Muted Teal - for card backgrounds and softer elements)
*   **Accent:** `#00F0FF` (Bioluminescent Cyan - for highlights, interactive elements, and glow effects)
*   **Background:** `#07101C` (Abyssal Depths - for the overall page background)
*   **Text:** `#E0EBF5` (Luminous White - for primary text, subtle and clear)

## Features

*   **Abyssal Aesthetic:** Visually striking design inspired by deep-sea environments.
*   **Dynamic Data Display:** Presents key data points (e.g., Pressure, Temperature, Light Level, Creature Count, Oxygen Saturation) with simulated real-time updates.
*   **Bioluminescent Accents:** Uses a vibrant cyan (`#00F0FF`) for subtle glowing effects, particularly around highlighted data cards.
*   **Responsive Layout:** Adapts gracefully to different screen sizes, from desktop to mobile.
*   **Modular Design:** Separated component logic (`.jsx`), styling (`.module.css`), and theme definitions (`theme.js`) for easy maintenance and customization.

## How to Run/Use

This component is built with React. To use it in your project:

### Prerequisites

*   A React project (created with Create React App, Vite, Next.js, etc.).
*   Node.js and npm/yarn installed.

### Installation

1.  **Copy Files:** Place the provided files into your React project structure:
    *   `theme.js` in your `src/` directory (or `src/config/`).
    *   `components/DeepSeaDataDisplay.jsx` in `src/components/DeepSeaDataDisplay.jsx`.
    *   `components/DeepSeaDataDisplay.module.css` in `src/components/DeepSeaDataDisplay.module.css`.
    *   `App.jsx` can replace your existing `src/App.jsx` for demonstration.
    *   `index.css` can replace or augment your existing `src/index.css`.

### Usage

1.  **Define Theme (if not using `App.jsx` provided):**
    Ensure `theme.js` is accessible.

    ```javascript
    // src/theme.js
    const theme = {
      colors: {
        primary: '#0A1C2C',
        secondary: '#1A4F6D',
        accent: '#00F0FF',
        background: '#07101C',
        text: '#E0EBF5',
        textMuted: '#8BA4B5',
      },
      fonts: {
        body: 'Arial, sans-serif',
        display: 'Montserrat, sans-serif',
      },
      spacing: {
        small: '8px',
        medium: '16px',
        large: '24px',
      },
      borderRadius: '8px',
    };
    export default theme;
    ```

2.  **Import and Render the Component:**
    In your main application file (e.g., `src/App.jsx` or a page component):

    ```javascript
    // src/App.jsx
    import React from 'react';
    import DeepSeaDataDisplay from './components/DeepSeaDataDisplay';
    import theme from './theme'; // Adjust path if necessary
    import './index.css'; // Global styles for body and fonts

    function App() {
      return (
        <div style={{ backgroundColor: theme.colors.background, minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <DeepSeaDataDisplay />
        </div>
      );
    }

    export default App;
    ```

3.  **Global Styles (for font imports and body background):**
    Ensure your `src/index.css` (or equivalent global stylesheet) includes the Montserrat font import and sets the body background.

    ```css
    /* src/index.css */
    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
        'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
        sans-serif;
      -webkit-font-smoothing: antialiased;
      -moz-osx-smoothing: grayscale;
      background-color: #07101C; /* Abyssal Depths background */
      color: #E0EBF5; /* Luminous White text */
    }

    /* Import Google Fonts - Montserrat */
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;700&display=swap');
    ```

4.  **Run Your React Application:**
    ```bash
    npm start
    # or
    yarn start
    ```
    Your browser should open, displaying the "Abyssal Lumina Calm" Deep Sea Data Monitor.

## Customization

*   **Data:** Modify the `DeepSeaDataDisplay.jsx` component to fetch and display your actual data instead of simulated values.
*   **Colors:** Update the `theme.js` file to adjust the color palette. Changes will propagate throughout the component.
*   **Layout & Styling:** Edit `DeepSeaDataDisplay.module.css` to change spacing, fonts, card appearance, and bioluminescent effects.
*   **Responsiveness:** Adjust media queries in `DeepSeaDataDisplay.module.css` to fine-tune responsiveness for specific breakpoints.

Embrace the calm depths and enjoy your tranquil data monitoring experience!