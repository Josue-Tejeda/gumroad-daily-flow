/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'clay-primary': '#B36A5E',       // Sundried Clay
        'desert-secondary': '#E0C7A9',   // Desert Bloom Light
        'desert-accent': '#F29E4C',      // Desert Bloom Vibrant
        'desert-background': '#F7F1E7', // Desert Sand
        'earth-text': '#3D2B2B',         // Deep Earth
      },
      fontFamily: {
        sans: ['"Inter"', 'sans-serif'],
      },
      boxShadow: {
        'golden-glow': '0 15px 30px -5px rgba(179, 106, 94, 0.3), 0 8px 15px -3px rgba(242, 158, 76, 0.15)',
        'soft-depth': '0 10px 20px -5px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)',
      },
      borderRadius: {
        'adobe': '1.5rem',
        'terracotta': '2.5rem',
      },
    },
  },
  plugins: [],
}