# Neo-Brutal Grid System Status Card

## 🚀 Component Description
The `NeoBrutalGridCard` is a React component designed to display critical system metrics in a stark, functional, and visually striking "Neo-Brutal Grid" aesthetic. It's ideal for dashboards, monitoring interfaces, or any application requiring a robust, future-forward utilitarian look. This component dynamically simulates CPU, RAM, Disk usage, and Network activity, complete with real-time updates and a system status indicator.

## 🎨 Theme Inspiration: Neo-Brutal Grid
This component embodies the "Neo-Brutal Grid" theme, a powerful fusion of brutalist architecture and cyberpunk futurism. It's characterized by:
*   **Stark Functionality:** Prioritizing utility and clarity with clean, grid-based layouts and robust typography.
*   **Raw & Industrial:** Monolithic forms, rectilinear shapes, and textures reminiscent of unpolished concrete and dark, brushed steel. Subtle digital noise and grain add to the authenticity.
*   **Ethereal Digital Glow:** Heavy elements are layered with intricate, glowing circuit patterns, exposed digital grids, and vibrant neon accents that trace edges and highlight interactive data.
*   **Dramatic Lighting:** Primary illumination from intense, focused neon strips and backlights, creating sharp contrasts and deep shadows, giving it an atmospheric feel.

## ✨ Design System Choices

### Colors
The component meticulously integrates the defined color palette to achieve its distinctive aesthetic:
*   **Primary (`--color-primary`): `#212529`**
    *   Used for the main background of elements, providing a deep, weighty base.
*   **Secondary (`--color-secondary`): `#6C757D`**
    *   A muted grey, used for borders, dividers, and subtle grid lines, reinforcing the industrial feel.
*   **Accent (`--color-accent`): `#00FFE0`**
    *   The vibrant neon teal, used for progress bars, highlighted text, and glowing effects, representing digital energy and interactive elements.
*   **Background (`--color-background`): `#121212`**
    *   The overall deep, dark background of the application, enhancing the contrast and dramatic lighting.
*   **Text (`--color-text`): `#E0E0E0`**
    *   A light, legible grey for primary text, ensuring readability against dark backgrounds.

### Typography
*   **Font Family:** `Roboto Mono` (monospace) is chosen for its technical, utilitarian, and digital feel, perfectly complementing the cyberpunk aesthetic.
*   **Weight & Size:** Robust weights for titles and clear, concise sizing for data points ensure readability and maintain the component's functional nature.

### Layout & Visuals
*   **Grid-Based:** The internal layout of metrics is organized using CSS Grid, reflecting the "Grid" aspect of the theme.
*   **Monolithic Forms:** The card itself is a prominent, rectangular block, echoing brutalist architectural elements.
*   **Layered Textures:** Subtle background patterns (digital grid, noise) are achieved using CSS pseudo-elements and gradients, adding depth without clutter.
*   **Neon Glows:** `box-shadow` and `text-shadow` properties are extensively used with the accent color to create the signature neon light effects.
*   **Transitions:** Smooth CSS transitions are applied to progress bars and hover states for a modern, interactive experience.

## 📦 Installation

To use this component in your React project, simply copy the provided files into your `src` directory.

1.  **Create the directory structure:**
    ```
your-react-app/
├── src/
│   ├── components/
│   │   └── NeoBrutalGridCard.jsx
│   └── styles/
│       └── neoBrutalGridTheme.css
├── public/
├── README.md
└── ...
    ```
2.  **Ensure `Roboto Mono` is available.** The `neoBrutalGridTheme.css` includes an `@import` rule for Google Fonts, so an internet connection is required for the font to load.

## ⚙️ Configuration

The component's styling is highly customizable through CSS variables defined in `src/styles/neoBrutalGridTheme.css`.

*   **Color Customization:**
    Change any of the `--color-*` variables to update the component's color scheme.
    ```css
:root {
  --color-primary: #2C3E50; /* Example: a darker blue-grey */
  --color-accent: #FF6B6B; /* Example: a vibrant red neon */
  /* ... other colors ... */
}
    ```
*   **Styling Tweaks:**
    Adjust `--brutal-border-width`, `--brutal-shadow`, `--neon-glow-intensity`, or `--brutal-grid-pattern` to fine-tune the brutalist and cyberpunk effects.
    The status colors (`.status-degraded`, `.status-offline`, `.status-rebooting`) can also be updated directly in the CSS file.

## 📝 Usage

Import the `NeoBrutalGridCard` component into any of your React components (e.g., `App.jsx`) and render it.

```jsx
// src/App.jsx or any other React component
import React from 'react';
import NeoBrutalGridCard from './components/NeoBrutalGridCard';
import './styles/neoBrutalGridTheme.css'; // Make sure to import the theme CSS globally or where appropriate

function App() {
  return (
    <div className="App" style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      backgroundColor: 'var(--color-background)',
      padding: '20px'
    }}>
      <NeoBrutalGridCard />
    </div>
  );
}

export default App;
```

Ensure your root `App` component or a higher-level component is wrapped in a `div` that sets the `--color-background` for the entire page, as shown in the `App.jsx` example, or ensure `body` styles from `neoBrutalGridTheme.css` are active.

## Live Demo (Conceptual)
Once integrated into a React project, the card will display continuously updating system metrics with a dynamic status indicator and the distinctive Neo-Brutal Grid visual styling.
```
CPU: [||||||||||||||||||||||||        ] 65%
RAM: [||||||||||||||||||||||||||||||  ] 82%
DISK:[||||||||||||||||||||||||||||||||] 91%
NET: ⬇️ 12.34 MB/s ⬆️ 4.56 MB/s

Status: 🟢 Online
Last update: 10:30:45 AM
```

---