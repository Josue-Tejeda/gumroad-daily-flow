import React from 'react';

const DesertProductCard = ({
  imageSrc = "https://via.placeholder.com/160/B36A5E/F7F1E7?text=Product",
  imageAlt = "Product Image",
  title = "Terracotta Planter",
  description = "Handcrafted from natural sundried clay, this planter features a rustic texture and an organic, rounded design perfect for bringing desert warmth to your home.",
  price = "$39.99",
  buttonText = "View Details",
  onButtonClick = () => console.log('Button clicked!'),
}) => {
  return (
    <div className="
      relative
      bg-desert-secondary
      text-earth-text
      rounded-adobe
      shadow-golden-glow
      overflow-hidden
      max-w-sm
      mx-auto
      p-6
      flex
      flex-col
      items-center
      text-center
      transition-all
      duration-500
      ease-in-out
      hover:scale-[1.02]
      hover:shadow-soft-depth
      group
    ">
      {/* Abstract background glow/shape 1 */}
      <div className="
        absolute
        -top-8
        -left-8
        w-32
        h-32
        bg-clay-primary
        rounded-full
        opacity-20
        filter
        blur-xl
        transition-opacity
        duration-500
        ease-in-out
        group-hover:opacity-30
      "></div>
      {/* Abstract background glow/shape 2 */}
      <div className="
        absolute
        -bottom-8
        -right-8
        w-36
        h-36
        bg-desert-accent
        rounded-full
        opacity-15
        filter
        blur-2xl
        transition-opacity
        duration-500
        ease-in-out
        group-hover:opacity-25
      "></div>

      {imageSrc && (
        <div className="
          relative
          w-40
          h-40
          mb-4
          rounded-full
          overflow-hidden
          border-4
          border-clay-primary
          shadow-md
          transition-transform
          duration-300
          ease-in-out
          hover:scale-105
        ">
          <img
            src={imageSrc}
            alt={imageAlt}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      <h3 className="
        text-2xl
        font-semibold
        mb-2
        text-clay-primary
      ">
        {title}
      </h3>
      <p className="
        text-sm
        mb-4
        leading-relaxed
        opacity-80
      ">
        {description}
      </p>

      <div className="
        flex
        items-baseline
        gap-2
        mb-6
      ">
        {price && (
          <span className="
            text-4xl
            font-bold
            text-desert-accent
          ">
            {price}
          </span>
        )}
        <span className="
          text-lg
          font-medium
          text-earth-text
          opacity-70
        ">
          USD
        </span>
      </div>

      <button
        onClick={onButtonClick}
        className="
          bg-clay-primary
          hover:bg-desert-accent
          text-white
          font-bold
          py-3
          px-8
          rounded-full
          transition-all
          duration-300
          ease-in-out
          shadow-md
          hover:shadow-lg
          transform
          hover:-translate-y-1
          focus:outline-none
          focus:ring-2
          focus:ring-clay-primary
          focus:ring-opacity-75
        "
      >
        {buttonText}
      </button>
    </div>
  );
};

export default DesertProductCard;
