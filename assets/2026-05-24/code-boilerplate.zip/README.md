# Sundried Clay & Desert Bloom Product Card

Embrace the tranquil warmth and organic beauty of sun-baked earth meeting the subtle vibrancy of desert flora with this handcrafted Product Card component. Designed as a premium developer asset, this card seamlessly integrates into your React projects, offering a unique aesthetic inspired by "Sundried Clay & Desert Bloom."

## Theme Inspiration: Sundried Clay & Desert Bloom

This component's design ethos is deeply rooted in the concept of sun-baked earth meeting the subtle vibrancy of desert flora. It evokes a sense of tranquil warmth, organic beauty, and handcrafted sensibility.

### Aesthetic Styling Details:
*   **Forms:** Grounded in natural, organic forms with soft, rounded edges and gentle curves, reminiscent of adobe architecture and eroded rock formations.
*   **Textures:** Subtle graininess of clay and fine desert sand, implied through color gradients and shadow play, contrasted with smooth, cool elements (achieved with smooth surfaces and gentle transitions).
*   **Lighting:** Soft and diffused, evoking a perpetual golden hour glow with deep, comforting shadows, creating a sense of depth and peaceful serenity.
*   **Design Elements:** Subtle archways (implied through rounded corners), terracotta pot inspirations (color palette and form), and abstract botanical motifs in muted tones, avoiding harsh lines for a fluid, inviting experience.

### Color Palette:
To maintain cohesiveness and theme integrity, the following custom Tailwind CSS colors are utilized:

*   **Primary (Sundried Clay):** `#B36A5E`
*   **Secondary (Desert Bloom Light):** `#E0C7A9`
*   **Accent (Desert Bloom Vibrant):** `#F29E4C`
*   **Background (Desert Sand):** `#F7F1E7`
*   **Text (Deep Earth):** `#3D2B2B`

## Features

*   **Responsive Design:** Adapts gracefully to various screen sizes.
*   **Themed Styling:** Pre-styled with the "Sundried Clay & Desert Bloom" aesthetic using Tailwind CSS.
*   **Customizable Content:** Easily update image, title, description, price, and button text via props.
*   **Interactive Elements:** Smooth hover effects and transitions for an engaging user experience.
*   **Modern Design Paradigms:** Utilizes subtle shadows for depth (golden hour glow), rounded organic shapes, and a clean layout.
*   **Easy Integration:** A standalone React component ready to be dropped into any React project using Tailwind CSS.

## Installation

This component requires [React](https://reactjs.org/) and [Tailwind CSS](https://tailwindcss.com/).

### 1. Create a React Project (if you don't have one)

```bash
npx create-react-app my-desert-app --template typescript # or without --template typescript for JS
cd my-desert-app
```

### 2. Install Tailwind CSS

Follow the official Tailwind CSS installation guide for Create React App:

```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

This will create `tailwind.config.js` and `postcss.config.js` in your project root.

### 3. Configure Tailwind CSS

Update your `tailwind.config.js` to include the custom theme colors and content paths.

```javascript
// tailwind.config.js
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'clay-primary': '#B36A5E',       // Sundried Clay
        'desert-secondary': '#E0C7A9',   // Desert Bloom Light
        'desert-accent': '#F29E4C',      // Desert Bloom Vibrant
        'desert-background': '#F7F1E7', // Desert Sand
        'earth-text': '#3D2B2B',         // Deep Earth
      },
      fontFamily: {
        sans: ['"Inter"', 'sans-serif'], // Recommended font, or use your project's default
      },
      boxShadow: {
        'golden-glow': '0 15px 30px -5px rgba(179, 106, 94, 0.3), 0 8px 15px -3px rgba(242, 158, 76, 0.15)', // Soft, diffused glow
        'soft-depth': '0 10px 20px -5px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)', // Standard hover depth
      },
      borderRadius: {
        'adobe': '1.5rem',      // Larger, organic rounded edges
        'terracotta': '2.5rem', // Even more rounded for specific elements
      },
    },
  },
  plugins: [],
}
```

### 4. Add Tailwind Directives to your CSS

Create or update `src/index.css` (or `src/App.css` if that's your main stylesheet) with the Tailwind directives and general body styles.

```css
/* src/index.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  background-color: #F7F1E7; /* Matches 'desert-background' */
  font-family: 'Inter', sans-serif; /* Ensure Inter is available or use your preferred font */
  color: #3D2B2B; /* Matches 'earth-text' */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
```

Ensure `src/index.js` imports this CSS file: `import './index.css';`

### 5. Add the `DesertProductCard` Component

Create a new file `src/components/DesertProductCard.jsx` and paste the component code:

```jsx
// src/components/DesertProductCard.jsx
import React from 'react';

const DesertProductCard = ({
  imageSrc = "https://via.placeholder.com/160/B36A5E/F7F1E7?text=Product",
  imageAlt = "Product Image",
  title = "Terracotta Planter",
  description = "Handcrafted from natural sundried clay, this planter features a rustic texture and an organic, rounded design perfect for bringing desert warmth to your home.",
  price = "$39.99",
  buttonText = "View Details",
  onButtonClick = () => console.log('Button clicked!'),
}) => {
  return (
    <div className="
      relative
      bg-desert-secondary
      text-earth-text
      rounded-adobe
      shadow-golden-glow
      overflow-hidden
      max-w-sm
      mx-auto
      p-6
      flex
      flex-col
      items-center
      text-center
      transition-all
      duration-500
      ease-in-out
      hover:scale-[1.02]
      hover:shadow-soft-depth
      group
    ">
      {/* Abstract background glow/shape 1 */}
      <div className="
        absolute
        -top-8
        -left-8
        w-32
        h-32
        bg-clay-primary
        rounded-full
        opacity-20
        filter
        blur-xl
        transition-opacity
        duration-500
        ease-in-out
        group-hover:opacity-30
      "></div>
      {/* Abstract background glow/shape 2 */}
      <div className="
        absolute
        -bottom-8
        -right-8
        w-36
        h-36
        bg-desert-accent
        rounded-full
        opacity-15
        filter
        blur-2xl
        transition-opacity
        duration-500
        ease-in-out
        group-hover:opacity-25
      "></div>

      {imageSrc && (
        <div className="
          relative
          w-40
          h-40
          mb-4
          rounded-full
          overflow-hidden
          border-4
          border-clay-primary
          shadow-md
          transition-transform
          duration-300
          ease-in-out
          hover:scale-105
        ">
          <img
            src={imageSrc}
            alt={imageAlt}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      <h3 className="
        text-2xl
        font-semibold
        mb-2
        text-clay-primary
      ">
        {title}
      </h3>
      <p className="
        text-sm
        mb-4
        leading-relaxed
        opacity-80
      ">
        {description}
      </p>

      <div className="
        flex
        items-baseline
        gap-2
        mb-6
      ">
        {price && (
          <span className="
            text-4xl
            font-bold
            text-desert-accent
          ">
            {price}
          </span>
        )}
        <span className="
          text-lg
          font-medium
          text-earth-text
          opacity-70
        ">
          USD
        </span>
      </div>

      <button
        onClick={onButtonClick}
        className="
          bg-clay-primary
          hover:bg-desert-accent
          text-white
          font-bold
          py-3
          px-8
          rounded-full
          transition-all
          duration-300
          ease-in-out
          shadow-md
          hover:shadow-lg
          transform
          hover:-translate-y-1
          focus:outline-none
          focus:ring-2
          focus:ring-clay-primary
          focus:ring-opacity-75
        "
      >
        {buttonText}
      </button>
    </div>
  );
};

export default DesertProductCard;
```

## Usage Example

Import and use the `DesertProductCard` component in your `App.js` or any other React component.

```jsx
// src/App.js
import React from 'react';
import DesertProductCard from './components/DesertProductCard';
import './index.css'; // Ensure your main CSS is imported

function App() {
  const handleAddToCart = () => {
    alert('Item added to cart!');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-desert-background p-4">
      <DesertProductCard
        imageSrc="https://images.unsplash.com/photo-1596207850024-c1032ee09d00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxfDB8MXxyYW5kb218MHx8dGVycmFjb3R0YSwgcGxhbnRlcnw&ixlib=rb-1.2.1&q=80&w=400"
        imageAlt="Handcrafted Terracotta Pot"
        title="Artisan Desert Pot"
        description="A beautifully handcrafted pot inspired by traditional desert pottery, perfect for succulents or small desert blooms. Each piece tells a story of the sun and sand."
        price="$65.00"
        buttonText="Discover More"
        onButtonClick={handleAddToCart}
      />
    </div>
  );
}

export default App;
```

## Customization

You can customize the `DesertProductCard` by passing different props:

| Prop        | Type     | Default Value                                                                                                                                                                                                            | Description                                            |
| :---------- | :------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------- |
| `imageSrc`  | `string` | `"https://via.placeholder.com/160/B36A5E/F7F1E7?text=Product"`                                                                                                                                                           | URL of the product image.                              |
| `imageAlt`  | `string` | `"Product Image"`                                                                                                                                                                                                        | Alt text for the product image.                        |
| `title`     | `string` | `"Terracotta Planter"`                                                                                                                                                                                                   | The title of the product.                              |
| `description` | `string` | `"Handcrafted from natural sundried clay, this planter features a rustic texture and an organic, rounded design perfect for bringing desert warmth to your home."` | A brief description of the product.                    |
| `price`     | `string` | `"$39.99"`                                                                                                                                                                                                               | The price of the product (can be any formatted string). |
| `buttonText`| `string` | `"View Details"`                                                                                                                                                                                                         | Text for the call-to-action button.                    |
| `onButtonClick` | `function` | `() => console.log('Button clicked!')`                                                                                                                                                                                   | Callback function for the button click event.          |

## License

This project is open-sourced under the MIT License.
