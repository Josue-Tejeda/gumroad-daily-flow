import React, { useState, useEffect } from 'react';
import styles from './DeepSeaDataDisplay.module.css';
import theme from '../theme';

const DataCard = ({ label, value, unit, isAccent = false }) => (
  <div className={styles.dataCard} style={{ backgroundColor: theme.colors.secondary, borderColor: isAccent ? theme.colors.accent : theme.colors.primary }}>
    <p className={styles.cardLabel} style={{ color: theme.colors.textMuted }}>{label}</p>
    <h3 className={styles.cardValue} style={{ color: theme.colors.text }}>
      {value}
      {unit && <span className={styles.cardUnit} style={{ color: theme.colors.textMuted }}>{unit}</span>}
    </h3>
    {isAccent && <div className={styles.accentGlow}></div>}
  </div>
);

const DeepSeaDataDisplay = () => {
  const [data, setData] = useState({
    pressure: 1200,
    temperature: 3.5,
    lightLevel: 0.0001,
    creatureCount: 27,
    oxygenSaturation: 85,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prevData => ({
        pressure: Math.floor(1100 + Math.random() * 200),
        temperature: parseFloat((2 + Math.random() * 3).toFixed(1)),
        lightLevel: parseFloat((Math.random() * 0.0005).toFixed(5)),
        creatureCount: Math.floor(20 + Math.random() * 30),
        oxygenSaturation: Math.floor(75 + Math.random() * 20),
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={styles.container} style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}>
      <h2 className={styles.title} style={{ color: theme.colors.text }}>Abyssal Lumina Calm</h2>
      <p className={styles.subtitle} style={{ color: theme.colors.textMuted }}>Deep Sea Data Monitor</p>
      <div className={styles.dataGrid}>
        <DataCard label="Pressure" value={data.pressure} unit="dbar" />
        <DataCard label="Temperature" value={data.temperature} unit="°C" />
        <DataCard label="Light Level" value={data.lightLevel} unit="lux" isAccent={true} />
        <DataCard label="Creature Count" value={data.creatureCount} unit="" />
        <DataCard label="O₂ Saturation" value={data.oxygenSaturation} unit="%" />
      </div>
      <p className={styles.footer} style={{ color: theme.colors.textMuted }}>Data simulated from abyssal depths.</p>
    </div>
  );
};

export default DeepSeaDataDisplay;