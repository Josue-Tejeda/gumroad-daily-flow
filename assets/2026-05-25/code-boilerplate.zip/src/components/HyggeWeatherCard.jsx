import React from 'react';

const HyggeWeatherCard = ({
  location = "Cozy Nook",
  temperature = "18°C",
  condition = "Partly Cloudy",
  comfortLevel = "Perfect for a warm beverage and a good book.",
  activitySuggestion = "Brew some tea and curl up by the fireplace.",
}) => {
  return (
    <div className="
      relative
      bg-hygge-secondary
      text-hygge-text
      p-6 md:p-8
      rounded-3xl
      shadow-hygge-soft
      max-w-md w-full
      font-body
      overflow-hidden
      transition-all duration-300 ease-in-out
      hover:shadow-hygge-hover hover:scale-[1.01]
    " style={{
      backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'6\' height=\'6\' viewBox=\'0 0 6 6\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'%23F3E9DD\' fill-opacity=\'0.8\' fill-rule=\'evenodd\'%3E%3Cpath d=\'M5 0h1L0 6V5zm1 5v1H5z\'/%3E%3C/g%3E%3C/svg%3E")',
      backgroundSize: '16px 16px',
    }}>
      {/* Main card content */}
      <div className="relative z-10 flex flex-col h-full justify-between">
        {/* Header Section */}
        <div className="mb-4">
          <h2 className="text-2xl md:text-3xl font-display font-semibold text-hygge-primary mb-1">
            {location} Retreat
          </h2>
          <p className="text-sm md:text-base text-hygge-primary opacity-80">Current Comfort</p>
        </div>

        {/* Main Weather & Comfort Info */}
        <div className="flex-grow flex flex-col justify-center items-center text-center py-4">
          <div className="flex items-center justify-center gap-3 mb-2">
            {/* Weather Icon Placeholder */}
            <span className="text-4xl md:text-5xl" role="img" aria-label="weather-icon">
              {condition.includes("Sun") ? "☀️" : condition.includes("Cloud") ? "☁️" : condition.includes("Rain") ? "🌧️" : "🌡️"}
            </span>
            <p className="text-4xl md:text-5xl font-display font-bold text-hygge-accent">
              {temperature}
            </p>
          </div>
          <p className="text-lg md:text-xl font-medium text-hygge-primary mb-3">{condition}</p>
          <p className="text-base text-hygge-text leading-relaxed italic opacity-90">
            "{comfortLevel}"
          </p>
        </div>

        {/* Footer with activity suggestion */}
        <div className="
          mt-6 pt-4
          border-t border-hygge-primary/[0.2]
          text-center
          flex items-center justify-between gap-2
          flex-col sm:flex-row
        ">
          <span className="text-hygge-primary text-sm font-medium">✨ Cozy Tip:</span>
          <p className="text-sm md:text-base text-hygge-text opacity-90 sm:text-right">
            {activitySuggestion}
          </p>
        </div>
      </div>
    </div>
  );
};

export default HyggeWeatherCard;
